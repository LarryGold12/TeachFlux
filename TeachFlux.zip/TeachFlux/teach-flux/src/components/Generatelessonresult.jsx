import React from "react";

const Generatelessonresult = () => {
  return (
    <div className="lesson-result">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel architecto
        quasi eum distinctio minus minima magni pariatur illo nesciunt,
        voluptatum magnam dolorum ut enim rem, temporibus dignissimos? Harum,
        voluptatibus expedita! Unde minus sed, culpa amet vel consequuntur
        fugit. Perspiciatis corporis minima nemo. Sed facilis error consectetur
      </p>
    </div>
  );
};

export default Generatelessonresult;
