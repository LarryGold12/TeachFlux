import React from "react";

const Graderesult = () => {
  return (
    <div className="grade-result">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. In, facere!
        Eveniet explicabo dicta animi labore inventore rerum unde cum reiciendis
        obcaecati ea, veniam esse consectetur, facere voluptatum illum neque!
        Hic.
      </p>
    </div>
  );
};

export default Graderesult;
