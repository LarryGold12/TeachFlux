import React from "react";

const Feedbackpage = () => {
  return <div>Feedbackpage</div>;
};

export default Feedbackpage;
